package com.example.the_newapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
